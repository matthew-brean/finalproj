﻿using UnityEngine;
using System.Collections;

public class switchtotutorial2 : MonoBehaviour {

    void OnMouseUp()
    {
        Application.LoadLevel("Tutorial2");
    }
}

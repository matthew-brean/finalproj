﻿using UnityEngine;
using System.Collections;

public class tolevel4 : MonoBehaviour {

    void OnMouseUp()
    {
        Application.LoadLevel("level4");
        //SceneManager.LoadScene("level3");

    }
}

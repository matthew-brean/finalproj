﻿using UnityEngine;
using System.Collections;

public class switchToInstructionsScreen : MonoBehaviour {


    //the following code makes it so when the button (instructions) is pressed, it changes the scene to the scene titled instructions

    void OnMouseUp()
    {
        Application.LoadLevel("instructions");
    }
}

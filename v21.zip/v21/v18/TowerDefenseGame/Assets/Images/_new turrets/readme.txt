difficult to switch for current turrets
leave these here for an update
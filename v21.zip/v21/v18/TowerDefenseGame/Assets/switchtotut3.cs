﻿using UnityEngine;
using System.Collections;

public class switchtotut3 : MonoBehaviour {


        void OnMouseUp()
    {
            Application.LoadLevel("Tutorial3");
        }

    }

﻿using UnityEngine;
using System.Collections;

public class backToMainMenu : MonoBehaviour {


    //switches back to the main menu
    public void OnMouseUp()
    {
        Application.LoadLevel("MainMenuScene");
    }

}

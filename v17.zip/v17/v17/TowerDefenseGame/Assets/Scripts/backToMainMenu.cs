﻿using UnityEngine;
using System.Collections;

public class backToMainMenu : MonoBehaviour {


    //switches back to the main menu
    void OnMouseUp()
    {
        Application.LoadLevel("MainMenuScene");
    }

}

﻿using UnityEngine;
using System.Collections;

public class nUTTONScript : MonoBehaviour {

    void OnMouseUp()
    {
        Application.LoadLevel("GameScene");
    }

}

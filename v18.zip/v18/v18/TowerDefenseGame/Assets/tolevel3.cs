﻿using UnityEngine;
using System.Collections;

public class tolevel3 : MonoBehaviour {

    void OnMouseUp()
    {
        Application.LoadLevel("level3");
        //SceneManager.LoadScene("level3");

    }
}

﻿using UnityEngine;
using System.Collections;

public class switchToTutorial : MonoBehaviour
{


    //the following code makes it so when the button (tutorial) is pressed, it changes the scene to the scene titled Tutorial

    void OnMouseUp()
    {
        Application.LoadLevel("Tutorial");
    }
}

﻿using UnityEngine;
using System.Collections;

public class switchtotut4 : MonoBehaviour {

    void OnMouseUp()
    {
        Application.LoadLevel("Tutorial4");
    }
}

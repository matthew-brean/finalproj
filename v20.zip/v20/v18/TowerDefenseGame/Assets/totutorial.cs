﻿using UnityEngine;
using System.Collections;

public class totutorial : MonoBehaviour {

    void OnMouseUp()
    {
        Application.LoadLevel("Tutorial");
    }

}

﻿using UnityEngine;
using System.Collections;

public class tolevel2 : MonoBehaviour {

    void OnMouseUp()
    {
        Application.LoadLevel("level2");
    }
}

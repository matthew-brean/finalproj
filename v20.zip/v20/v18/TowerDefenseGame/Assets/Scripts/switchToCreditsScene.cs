﻿using UnityEngine;
using System.Collections;

public class switchToCreditsScene : MonoBehaviour {

    //the following code makes it so when the button (Credits) is pressed, it changes the scene to the scene titled Credits

    void OnMouseUp()
    {
        Application.LoadLevel("Credits");
    }
}
